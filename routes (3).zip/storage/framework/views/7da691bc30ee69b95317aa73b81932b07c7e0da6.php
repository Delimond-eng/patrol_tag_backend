<!DOCTYPE html>

<html lang="en" class="light">
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<head>
    <meta charset="utf-8">
    <link href="assets/images/logo.svg" rel="shortcut icon">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Icewall admin for weeding app">
    <meta name="keywords" content="Rapid Tech Property">
    <meta name="author" content="Gaston Delimond Dev">
    <title>Icewall weeding</title>
    <!-- BEGIN: CSS Assets-->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/app.css')); ?>" />
    <!-- END: CSS Assets-->
</head>
<!-- BEGIN: JS Assets-->
<body class="login">
    <?php echo $__env->yieldContent("content"); ?>
    <!-- BEGIN: Js assets -->
    <script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>
    <?php echo $__env->yieldContent("scripts"); ?>
    <!-- END: JS Assets-->
</body>

</html>
<?php /**PATH E:\WEB\LARAVEL\icewall-weeding\resources\views/layouts/auth.blade.php ENDPATH**/ ?>