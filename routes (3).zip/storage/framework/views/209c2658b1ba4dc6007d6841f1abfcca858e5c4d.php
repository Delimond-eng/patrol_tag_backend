<!DOCTYPE html>

<html lang="en" class="light">
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<head>
    <meta charset="utf-8">
    <link href="assets/images/logo.svg" rel="shortcut icon">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Icewall admin for weeding app">
    <meta name="keywords" content="Rapid Tech Property">
    <meta name="author" content="Gaston Delimond Dev">
    <title>Icewall weeding</title>
    <!-- BEGIN: CSS Assets-->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/app.css')); ?>" />
    <!-- END: CSS Assets-->
</head>
<!-- BEGIN: JS Assets-->
<body class="main">
    <!-- BEGIN: Mobile Menu -->
    <?php echo $__env->make("components.mobile_menu", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- END: Mobile Menu -->
    <!-- BEGIN: Top Bar -->
    <?php echo $__env->make("components.top_bar_fixed", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- END: Top Bar -->

    <!-- BEGIN: Top Menu -->
    <?php echo $__env->make("components.top_nav", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- END: Top Menu -->


    <div class="wrapper wrapper--top-nav">
        <div class="wrapper-box">
            <!-- BEGIN: Side Menu -->
            
            <!-- END: Side Menu -->
            <!-- BEGIN: Content -->
            <?php echo $__env->yieldContent("content"); ?>
            <!-- END: Content -->
        </div>
    </div>


    <!-- BEGIN: Js assets -->
    <script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>
    <?php echo $__env->yieldContent("scripts"); ?>
    <!-- END: JS Assets-->
</body>

</html>
<?php /**PATH E:\WEB\LARAVEL\icewall-weeding\resources\views/layouts/app.blade.php ENDPATH**/ ?>